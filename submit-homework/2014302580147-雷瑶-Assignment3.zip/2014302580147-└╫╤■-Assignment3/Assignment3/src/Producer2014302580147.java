
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Producer2014302580147 implements Runnable{
	private static Storage2014302580147 storage;        //�������ڵĲֿ�
	public static boolean isEnd = false;
	//���캯�������òֿ�
	public Producer2014302580147(Storage2014302580147 storage){
		Producer2014302580147.storage = storage;
	}
	
	//�ӽ�ʦ�б�ҳ���ȡ���н�ʦ��ҳ
	public static void getAllProUrls() throws IOException{
		Document doc = Jsoup.connect("http://www.wpi.edu/academics/cs/research-interests.html").get();
		
		Elements div = doc.select("[class=half]");
		Elements hrefs = div.select("a");
		ArrayList<String> proUrlList = new ArrayList<String>();
		
		File dir =new File(".\\Pages");		
		if(!dir .exists() && !dir.isDirectory()){
			System.out.println("Created sub directory 'Pages' successfuly.");  
		    dir.mkdir();    
		} else{  
		    System.out.println("The directory already exists!");  
		}
		 
		
		for(Element href:hrefs){
			String linkHref = href.attr("abs:href");
			//System.out.println(linkHref);
			proUrlList.add(linkHref);
		}
		proUrlList.remove(1);//ɾȥsms����ҳ��Ч��
		proUrlList.remove(6);//ɾȥnth����ʽ������
		for(String list:proUrlList){
			//System.out.println(list);
			HttpRequest response = HttpRequest.get(list);
			String[] s = list.split("\\/");
			String pageName = s[5];
			//System.out.println(pageName);
			if(response.ok()){
				File page = new File(".\\Pages\\"+pageName);
				response.receive(new File(".\\Pages\\"+pageName));
				System.out.println("Got a professor's homepage: "+pageName);
				storage.produce(page);
			}
		}
		
		isEnd = true;
	}
	
	public void run(){
		try{
			getAllProUrls();
		}catch(IOException e){
			System.out.println("Producing error");
		}
	}

	
}