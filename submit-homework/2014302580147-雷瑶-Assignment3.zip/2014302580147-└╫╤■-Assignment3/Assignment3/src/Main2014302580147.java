import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580147 {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		//���߳�
		//SingleThreadProcessing();
		
		//���߳�
		MultiThreadProcessing();
	}
	
	//���̴߳���
	public static void SingleThreadProcessing() throws IOException{
		System.out.println("**********SingleThread Processing Begin!**********");
		long startTime = System.currentTimeMillis();
		
		Document doc = Jsoup.connect("http://www.wpi.edu/academics/cs/research-interests.html").get();
		Elements div = doc.select("[class=half]");
		Elements hrefs = div.select("a");
		ArrayList<String> proUrlList = new ArrayList<String>();
		
		File dir =new File(".\\Pages");     
		if(!dir .exists() && !dir.isDirectory()){
			System.out.println("Created sub directory 'Pages' successfuly.");  
		    dir.mkdir();    
		} else{  
		    System.out.println("The directory already exists!");  
		}  
		for(Element href:hrefs){
			String linkHref = href.attr("abs:href");
			//System.out.println(linkHref);
			proUrlList.add(linkHref);
	         
			HttpRequest response = HttpRequest.get(linkHref);
			String[] s = linkHref.split("\\/");
			String pageName = s[5];
			System.out.println(pageName);
			if(response.ok()){
				response.receive(new File("Pages/"+pageName));
				System.out.println("Got a professor's homepage.");
			}
		}		
		File badPage = new File(".\\Pages\\nth.html");   //ɾȥnth.html����ʽ������
		if(badPage.exists()){
			badPage.delete();
		}
		
		File[] pages = dir.listFiles();
		for (File page : pages) {
			Consumer2014302580147.getProInfo(page);			
		}
		
		long endTime = System.currentTimeMillis();
		System.out.println("SingleThread Processing Time:"+(endTime - startTime));

	}
	
	//���̴߳���
	public static void MultiThreadProcessing() throws IOException, InterruptedException{
		System.out.println("**********MultiThread Processing Begin!**********");
		long startTime = System.currentTimeMillis();
		
		Storage2014302580147 storage = new Storage2014302580147();
		Producer2014302580147 producer = new Producer2014302580147(storage);
		Consumer2014302580147 consumer = new Consumer2014302580147(storage);	
		
        Thread t1 = new Thread(producer);
        Thread t2 = new Thread(consumer);

        t1.start();
        t2.start(); 
        
		t1.join();
		t2.join();
		
		long endTime = System.currentTimeMillis();
		System.out.println("MultiThread Processing Time:"+(endTime - startTime));
	}

}
