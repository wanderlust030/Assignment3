import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database2014302580147 {
    private String dbDriver="com.mysql.jdbc.Driver";   
    private String dbUrl="jdbc:mysql://localhost:3306/professorinfo?"; 
    private String dbUser="root";  
    private String dbPass="123456";  
    
    //�������ݿ�
    public Connection getConn()  
    {  
        Connection conn=null;  
        try {  
            Class.forName(dbDriver);  
        } catch (ClassNotFoundException e) {  
            e.printStackTrace();  
        }  
        try {  
            conn = DriverManager.getConnection(dbUrl,dbUser,dbPass);  
        } catch (SQLException e) {  
            e.printStackTrace();  
        }  
        System.out.println("���ݿ����ӳɹ���");
        return conn;  
    }  
    
    //�����ݿ��в�������
    public void InsertInfo(String[] proInfo){
    	Connection conn = null ; 
    	conn = getConn();
    	try{
    		String sql = "INSERT INTO professor_info(name,phone,email,Research_Interests,Education_Background) "
    				+ "VALUES('" + proInfo[0] + "','" + proInfo[1] + "','" + proInfo[2] + "','" + proInfo[3] + "','" + proInfo[4] + "')";
    		Statement st = conn.createStatement();
    		int count = st.executeUpdate(sql); 
    		System.out.println("��professor_info���в��� " + count + " ������");
    		conn.close();
    	} catch (SQLException e) {
    		 System.out.println("��������ʧ��" + e.getMessage());
    	}
    }
}
