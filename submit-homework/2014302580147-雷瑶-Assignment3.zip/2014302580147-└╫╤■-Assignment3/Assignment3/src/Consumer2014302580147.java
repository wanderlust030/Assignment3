
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Consumer2014302580147 implements Runnable{
	private Storage2014302580147 storage;        //�������ڵĲֿ�
	
	//���캯�������òֿ�
	public Consumer2014302580147(Storage2014302580147 storage){
		this.storage = storage;
	}
		
	//get a Processor's Name
	public static String getProName(Document doc){
		String proName = "";
		Elements h2s = doc.select("h2");
		proName = h2s.get(0).text();
		return proName;
	}
	
	//get a Professor's Phone
	public static String getProPhone(Document doc){
		String proPhone = "";
		Elements contact = doc.select("[id=contactinfo]");
		Elements p = contact.select("p");
		String content = p.text();
		Pattern pattern = Pattern.compile("\\+1\\-508\\-831\\-\\d+");
		Matcher m = pattern.matcher(content);
		if(m.find()){
			proPhone = m.group(0);
		}
		return proPhone;
	}
	
	//get a Professor's Email
	public static String getProEmail(Document doc){
		String proEmail = "";
		Elements contact = doc.select("[id=contactinfo]");
		proEmail = contact.select("a").text();
		return proEmail;
	}
	
	//get a Professor's Research Interests
	public static String getProInterests(Document doc){
		String proInterests = "";
		Elements div = doc.select("[class=col]");
		Elements ul = div.select("ul");
		Elements li = ul.select("li");
		int num = li.size();
		for(int i=0;i<num;i++){
			proInterests += li.get(i).text()+"\n";
		}
		return proInterests;
	}
	
	//get a Professor's Education Background
	public static String getProEduBkg(Document doc){
		String proEducation = "";
		Elements div = doc.select("[id=twocol]");
		Elements ul = div.select("ul");
		Elements li = ul.get(1).select("li");
		int num = li.size();
		for(int i=0;i<num;i++){
			proEducation += li.get(i).text()+"\n";
		}
		return proEducation;
	}
	
	//����һλ��ʦ��������Ϣ���洢��String[]��
	public static String[] getProInfo(File page) throws IOException{
		Document doc = Jsoup.parse(page, "utf-8");
		String name = getProName(doc);
		String phone = getProPhone(doc);
		String email = getProEmail(doc);
		String interests = getProInterests(doc);
		String education = getProEduBkg(doc);
		
		String[] proInfo ={name,phone,email,interests,education};
		Database2014302580147 db = new Database2014302580147();
		db.InsertInfo(proInfo);
		
		return proInfo;
	}
	
	public void run(){
		ArrayList<String[]> proInfo = new ArrayList<String[]>();
		while(true){
		try {
			String[] info = getProInfo(storage.consume());
			proInfo.add(info);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Producing error");
		}
		if (Producer2014302580147.isEnd) {
			break;
		}
		}
	}
}
